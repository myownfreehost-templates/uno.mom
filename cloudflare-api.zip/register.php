<?php    
    $apikey = 'cb4a53e7e042bb83c2e548aee056ca83a93ed'; // Cloudflare Global API Key
    $email = 'eu.com.ge@gmail.com'; // Cloudflare Email Address
    $domain = 'eu.com.ge';  // Zone_Name
    $zoneid = '5802e2587062f132634576a518ced163'; // CloudFlare zone id
    $type = $_POST['type']; // DNS Type (A,AAAA,CNAME,NS,TXT) vs.
    $name = $_POST['name']; // DNS Subdomain Name
    $content = $_POST['content']; // DNS Content

    		$ch = curl_init("https://api.cloudflare.com/client/v4/zones/".$zoneid."/dns_records");
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
    		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    		'X-Auth-Email: '.$email.'',
    		'X-Auth-Key: '.$apikey.'',
    	    'Content-Type:application/json'
    		));
 
    		$data = array(
    			'type' => ''.$type.'',
    			'name' => ''.$name.'',
    			'content' => ''.$content.'',
    			'proxied' => false,
    			'zone_id' => ''.$zoneid.'',
    			'zone_name' => ''.$domain.''
    		);
    		
    		$data_string = json_encode($data);

    		curl_setopt($ch, CURLOPT_POST, true);
    		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);	

    		$sonuc = curl_exec($ch);

    		curl_close($ch);
?>
<html>
<hrad>
<Title>.eu.com.ge subdomain registration</Title>
<meta charset="UTF-8">
  <meta name="description" content=".eu.com.ge free subdomain registration">
  <meta name="keywords" content="Subdomain, DNS">
  <meta name="author" content="Mehrab Mazmanian">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
<span style="position: absolute; left: 0; right: 0; top: 10%; margin-top: -50px; width: auto; height: auto; padding: 10px; margin: 10px; color: black; font-size: 14px;">
<center><h1><span class="badge bg-success">Success!</span></h1></center></span>
</body>
</html>
