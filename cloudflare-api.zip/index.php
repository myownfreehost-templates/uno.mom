<html>
<head>
<Title>.eu.com.ge subdomain registration</Title>
<meta charset="UTF-8">
  <meta name="description" content=".eu.com.ge free subdomain registration">
  <meta name="keywords" content="Subdomain, DNS">
  <meta name="author" content="Mehrab Mazmanian">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
<div class="container text-center justify-content-center"><span style="position: absolute; left: 0; right: 0; top: 10%; margin-top: -50px; width: auto; height: auto; padding: 10px; margin: 10px; color: black; font-size: 14px;">
<form class="row text-center justify-content-center" action="register.php" method="POST">
<div class="input-group mb-3">
<input type="text" class="form-control" placeholder="Subdomain" name="name"><span class="input-group-text">.eu.com.ge</span>
</div><div class="input-group mb-3">
<label class="btn btn-outline-secondary" for="a"><input type="radio" value="A" id="a" name="type"> A</label>
<label class="btn btn-outline-secondary" for="ns"><input type="radio" value="NS" id="ns" name="type"> NS</label>
<label class="btn btn-outline-secondary" for="cname"><input type="radio" value="CNAME" id="cname" name="type"> CNAME</label>
</div><div class="input-group mb-3">
<input type="text" class="form-control" placeholder="Content" name="content">
</div><div class="input-group mb-3">
<button class="btn btn-outline-primary">Register</button></span>
</div></div>
</form>
</body>
</html>
