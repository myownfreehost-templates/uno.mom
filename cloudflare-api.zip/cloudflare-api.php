<?php    
    $apikey = 'api-key'; // Cloudflare Global API Key
    $email = 'email'; // Cloudflare Email Address
    $domain = 'domain.com';  // Zone_Name
    $zoneid = 'zone-id'; // CloudFlare zone id
    $type = 'A'; // DNS Type (A,AAAA,CNAME,NS,TXT) vs.
    $name = 'subdomain'; // DNS Subdomain Name
    $content = '1.1.1.1'; // DNS Content

    		$ch = curl_init("https://api.cloudflare.com/client/v4/zones/".$zoneid."/dns_records");
    		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
    		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
    		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    		'X-Auth-Email: '.$email.'',
    		'X-Auth-Key: '.$apikey.'',
    	    'Content-Type:application/json'
    		));
 
    		$data = array(
    			'type' => ''.$type.'',
    			'name' => ''.$name.'',
    			'content' => ''.$content.'',
    			'proxied' => false,
    			'zone_id' => ''.$zoneid.'',
    			'zone_name' => ''.$domain.''
    		);
    		
    		$data_string = json_encode($data);

    		curl_setopt($ch, CURLOPT_POST, true);
    		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);	

    		$sonuc = curl_exec($ch);

    		curl_close($ch);
?>
